# Crea un Carousel Responsive Fácilmente con Glider.js
### [Tutorial: https://youtu.be/uDqW8bCFhps ](https://youtu.be/uDqW8bCFhps )

![Crea un Carousel Responsive Fácilmente con Glider.js](https://raw.githubusercontent.com/falconmasters/glider-js/master/img/thumb.png)

Por: [FalconMasters](http://www.falconmasters.com)